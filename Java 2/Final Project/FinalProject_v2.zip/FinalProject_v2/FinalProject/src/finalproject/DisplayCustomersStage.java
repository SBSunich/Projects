package finalproject;

import content.Customer;
import content.CustomerFile;
import java.io.IOException;
import java.util.ArrayList;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class DisplayCustomersStage extends Stage {

    private String elements = new String();
    private ArrayList<Customer> customerList = CustomerFile.getCustomerRecords();

    public DisplayCustomersStage(ArrayList<Customer> customerList) throws IOException {
        setScene(addScene());
    }

    private Scene addScene() {
        for (int sub = 0; sub < customerList.size(); sub++) {
            Customer one = customerList.get(sub);

            elements += "Customer ID: " + one.getID() + "\n"
                    + "Name: " + one.getName() + "\n"
                    + "Street Address: " + one.getStreetAdress() + "\n"
                    + "City: " + one.getCity() + "\n\n";

        }
        TextArea txtCustomers = new TextArea(elements);
        BorderPane pane = new BorderPane();
        pane.setCenter(txtCustomers);
        Scene scene = new Scene(pane, 400, 400);
        return scene;
    }
}
