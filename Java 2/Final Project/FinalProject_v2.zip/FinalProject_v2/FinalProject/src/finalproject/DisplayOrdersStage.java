package finalproject;

import content.Order;
import content.OrderFile;
import java.io.IOException;
import java.util.ArrayList;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class DisplayOrdersStage extends Stage {

    private String elements = new String();
    private ArrayList<Order> orderList = OrderFile.getOrders();

    public DisplayOrdersStage(ArrayList<Order> orderList) throws IOException {
        setScene(addScene());
    }

    private Scene addScene() {
        for (int sub = 0; sub < orderList.size(); sub++) {
            Order one = orderList.get(sub);

            elements += "Order ID: " + one.getOrderID() + "\n"
                    + "Customer ID: " + one.getCustomerID() + "\n"
                    + "Product: " + one.getProduct() + "\n"
                    + "Shipping Method: " + one.getShippingMethod() + "\n\n";

        }
        TextArea txtCustomers = new TextArea(elements);
        BorderPane pane = new BorderPane();
        pane.setCenter(txtCustomers);
        Scene scene = new Scene(pane, 400, 400);
        return scene;
    }
}
