
<a href="register.php">Register |</a> 
<a href="login.php">Login</a>

<hr>
