
<a href="logout.php">Log-Out |</a>
<a href="insert.php">Insert to Shoe Inventory |</a>
<a href="view.php">View Shoe Inventory</a>

<hr>
