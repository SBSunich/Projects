/**
 * Name: Sunil Sunichura
 * Student Number: 991578383
 * Assignment 1
 * Date: September 7, 2019
 */
package myinitials;


public class MyInitials {

   
    public static void main(String[] args) {
       
        System.out.print(" SSSSS\t\tBBBB\t\t SSSSS");
        System.out.print("\nS\t\tB   B\t\tS");
        System.out.print("\n SSSS\t\tBBBB\t\t SSSS");
        System.out.print("\n     S\t\tB   B\t\t     S");
        System.out.print("\nSSSSS\t\tBBBB\t\tSSSSS");
        System.out.print("\n\tSunil Sunichura\n");
    }
    
}
